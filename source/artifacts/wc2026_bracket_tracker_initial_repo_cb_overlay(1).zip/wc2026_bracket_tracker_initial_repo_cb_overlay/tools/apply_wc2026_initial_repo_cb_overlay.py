#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path.cwd()
OVERLAY = Path(__file__).resolve().parents[1]

SKIP = {"tools/apply_wc2026_initial_repo_cb_overlay.py"}

for src in OVERLAY.rglob("*"):
    if src.is_dir():
        continue
    rel = src.relative_to(OVERLAY)
    if str(rel) in SKIP:
        continue
    dst = ROOT / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

# If first release exists, create index.html for GitHub Pages.
release = ROOT / "releases/world_cup_bracket_tracker_v001.html"
if release.exists():
    shutil.copy2(release, ROOT / "index.html")
    html_dir = ROOT / "html"
    html_dir.mkdir(exist_ok=True)
    shutil.copy2(release, html_dir / "world_cup_bracket_tracker.html")

print("Applied WC2026 initial repo Capture Back overlay.")
