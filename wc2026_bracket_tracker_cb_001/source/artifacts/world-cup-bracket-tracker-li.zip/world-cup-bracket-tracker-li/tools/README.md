# Tools

Optional future tools may be added here.

Possible tools:

- validate_state.py
- score_brackets.py
- build_static_html.py
- check_release_consistency.py

The first implementation can be pure static HTML with manual II-assisted updates.
