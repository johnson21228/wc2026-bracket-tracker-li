WB_SESSION:
World Cup Bracket Tracker LI Initialized

Changed:
- Created Workbench LI skeleton for static World Cup bracket tracker.
- Added LI rules for source authority, bracket state, player scoring, static HTML releases, and update capture.
- Added starter data contracts for teams, bracket state, player brackets, and match results.
- Added prompts that allow any II reasoner to continue the project.
- Added cards for initial tracker, player bracket capture, result updates, and HTML release.
- Included the current static HTML builder as the working app, first release, and GitHub Pages index.

Sources:
- User direction in chat.
- Existing generated static HTML bracket builder.

Data affected:
- teams: starter contract only
- matches: starter contract only
- bracket: starter contract plus current HTML
- players: starter contract only
- scores: proposed rule source file only

Release:
- new: world_cup_bracket_tracker_v001.html

Unresolved:
- Confirm final scoring rules.
- Confirm whether player intake is manual, JSON import, Google Form, or future hosted backend.
- Confirm official team/group source to populate canonical `data/teams_2026.json`.

Next:
- Card 002: add player bracket intake and scoring surface.
