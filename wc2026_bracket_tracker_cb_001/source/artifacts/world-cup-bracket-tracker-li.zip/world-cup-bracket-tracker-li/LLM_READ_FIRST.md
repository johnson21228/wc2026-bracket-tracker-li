# LLM Read First

You are working inside the World Cup Bracket Tracker Workbench.

Do not treat this as a one-off HTML task. This is a continuity project.

Before changing files, read:

1. `MAP.md`
2. `li/world_cup/source_authority_rule.md`
3. `li/world_cup/bracket_state_rule.md`
4. `li/world_cup/player_scoring_rule.md`
5. `li/world_cup/static_html_release_rule.md`
6. `li/world_cup/update_capture_rule.md`

Every update must preserve:

- tournament facts
- player brackets
- scoring rules
- release history
- machine-readable state

If facts are uncertain, mark them as unresolved. Do not silently guess.
