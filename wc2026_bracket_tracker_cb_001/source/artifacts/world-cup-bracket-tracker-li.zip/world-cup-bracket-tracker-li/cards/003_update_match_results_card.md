# Card 003 — Update Match Results

## Intent

Update official match results as the tournament proceeds.

## Outputs

- updated match results
- advanced bracket winners
- updated HTML release
- capture note

## Acceptance

- Result source is recorded
- Affected matches are listed
- Player scoring impact is calculated or marked pending
