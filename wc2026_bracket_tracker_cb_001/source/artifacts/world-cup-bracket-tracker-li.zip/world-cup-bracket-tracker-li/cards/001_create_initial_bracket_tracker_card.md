# Card 001 — Create Initial Bracket Tracker

## Intent

Create the first static HTML file for the World Cup bracket tracker.

## Outputs

- `html/world_cup_bracket_tracker.html`
- `data/teams_2026.json`
- `data/bracket_state.json`
- first release copy in `releases/`

## Acceptance

- User can open HTML locally
- User can drag/drop teams into a 32-team bracket
- User can export/import JSON state
- HTML includes visible metadata
- HTML includes or can emit canonical machine-readable state
