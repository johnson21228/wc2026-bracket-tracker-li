# Card 002 — Capture Player Brackets

## Intent

Add player bracket intake and storage.

## Outputs

- player form or import surface in HTML
- `data/player_brackets.json`
- scoring lock policy

## Acceptance

- Each player has a stable id
- Picks are stored by match id
- Champion pick is explicit
- Export JSON preserves all player records
