# Card 004 — Release Static HTML

## Intent

Produce the next pass-around HTML release.

## Outputs

- immutable release under `releases/`
- optional `index.html` for GitHub Pages
- capture note

## Acceptance

- previous release is preserved
- new release has version/date
- embedded/exported JSON state matches visible bracket
