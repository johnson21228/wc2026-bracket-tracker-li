# World Cup Bracket Tracker LI

This Workbench maintains a static World Cup bracket tracker that can begin as a single downloadable HTML file and later evolve into a GitHub Pages site or lightweight server-backed app.

The Workbench exists to prevent tournament-state drift as results, player picks, scoring rules, and HTML releases change over time.

## Core idea

- The HTML file is the user-facing surface.
- The embedded/exported JSON is the durable portable state.
- The LI governs how any II reasoner updates the project.
- Capture Back records what changed and why.

## Initial workflow

1. Open `html/world_cup_bracket_tracker.html` locally.
2. Seed the bracket or collect player brackets.
3. Export JSON state from the page.
4. Paste the JSON or updated HTML into an II reasoner.
5. Ask the II to update results, scores, and produce the next HTML release.
6. Capture Back every update.

## Build posture

This project can be built from any II reasoner because the Workbench stores:

- source authority rules
- bracket data contracts
- scoring rules
- release rules
- update prompts
- cards describing the intended workflow
