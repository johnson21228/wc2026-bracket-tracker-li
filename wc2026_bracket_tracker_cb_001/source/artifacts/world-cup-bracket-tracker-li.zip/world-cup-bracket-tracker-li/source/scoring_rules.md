# Scoring Rules

Default scoring proposal:

| Round | Points |
|---|---:|
| Round of 32 winner | 1 |
| Round of 16 winner | 2 |
| Quarterfinal winner | 4 |
| Semifinal winner | 8 |
| Champion | 16 |

Status: proposed.

Before accepting player brackets, confirm whether this scoring system is final.
