# Tournament Format

The Workbench assumes a 48-team World Cup with a 32-team knockout phase.

The initial static page may support:

- all teams
- group labels
- drag/drop seeding into a 32-team bracket
- static release export/import
- later match results and scoring

Do not treat the bracket as final until the official knockout matchups are known.
