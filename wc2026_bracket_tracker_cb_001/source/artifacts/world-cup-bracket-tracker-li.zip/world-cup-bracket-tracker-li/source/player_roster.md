# Player Roster

Player records should be stored in `data/player_brackets.json`.

Do not overwrite player picks after lock without recording a correction.
