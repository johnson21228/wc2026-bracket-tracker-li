# Official Sources

Primary source should be FIFA official tournament materials.

Record source URLs or notes here as the tournament proceeds.

## Source log

| Date | Source | Used for | Notes |
|---|---|---|---|
| TBD | FIFA | Tournament format / fixtures / results | Add exact URLs during update |
