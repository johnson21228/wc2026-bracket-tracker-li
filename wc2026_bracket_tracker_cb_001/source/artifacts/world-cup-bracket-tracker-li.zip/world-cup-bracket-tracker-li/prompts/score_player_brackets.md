# Prompt — Score Player Brackets

```text
Score the player brackets against the current official match results.

Do not change player picks.
Do not change scoring rules unless explicitly instructed.
Show point changes since the previous release.
Return leaderboard, per-player deltas, updated JSON state, and capture note.
```
