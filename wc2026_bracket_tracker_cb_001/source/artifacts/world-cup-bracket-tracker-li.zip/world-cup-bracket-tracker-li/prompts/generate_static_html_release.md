# Prompt — Generate Static HTML Release

```text
Generate the next static HTML release for the World Cup Bracket Tracker.

Preserve all existing machine-readable state.
Update visible bracket, player scores, leaderboard, metadata, and release version.
The file must run locally with no build step and no server.
Also prepare an index.html copy if publishing to GitHub Pages.
```
