# Prompt — Capture Back Update

```text
Produce a WB_SESSION capture note for the latest World Cup Bracket Tracker change.

Include:
- what changed
- sources used
- files changed
- data affected
- player scoring impact
- release version
- unresolved items
- next recommended card
```
