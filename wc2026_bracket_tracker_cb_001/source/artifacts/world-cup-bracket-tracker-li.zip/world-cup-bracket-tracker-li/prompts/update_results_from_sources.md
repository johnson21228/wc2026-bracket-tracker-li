# Prompt — Update Results From Sources

Use this when match results have come in.

```text
You are updating the World Cup Bracket Tracker Workbench.

Read the LI first.

Use the latest provided HTML or exported JSON as canonical state.
Update match results only from cited sources or clearly marked manual overrides.

Return:
1. updated state summary
2. affected matches
3. affected player scores
4. next HTML release
5. WB_SESSION capture note
```
