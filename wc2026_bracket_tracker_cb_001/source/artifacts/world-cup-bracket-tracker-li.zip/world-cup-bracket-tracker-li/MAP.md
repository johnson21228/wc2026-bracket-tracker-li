# Project Map

## LI

- `li/world_cup/source_authority_rule.md` — how public facts are accepted
- `li/world_cup/bracket_state_rule.md` — canonical bracket state contract
- `li/world_cup/player_scoring_rule.md` — scoring and player bracket governance
- `li/world_cup/static_html_release_rule.md` — how static HTML releases are produced
- `li/world_cup/update_capture_rule.md` — how changes are captured back

## Source

- `source/official_sources.md` — trusted source list
- `source/tournament_format.md` — tournament structure
- `source/scoring_rules.md` — scoring policy
- `source/player_roster.md` — player list and intake policy

## Data

- `data/teams_2026.json` — team list
- `data/bracket_state.json` — canonical bracket state
- `data/player_brackets.json` — player submissions
- `data/match_results.json` — match/result records

## HTML

- `html/world_cup_bracket_tracker.html` — current working static app
- `releases/` — immutable released versions

## Cards

Cards describe work to do. They are not just notes.

## Prompts

Prompts allow any II reasoner to continue the workflow.
