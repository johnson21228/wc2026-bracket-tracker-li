# Bracket State Rule

## Purpose

The bracket is not only a visual drawing. It is a durable data object.

The canonical state must be machine-readable and portable between:

- static HTML
- exported JSON
- screenshots
- Workbench files
- later hosted versions

## Required bracket state fields

Each state object should include:

```json
{
  "version": "string",
  "generatedAt": "ISO-8601 date",
  "sourceVersion": "string",
  "teams": [],
  "slots": {},
  "matches": [],
  "winnerByMatchId": {},
  "notes": "",
  "changeLog": []
}
```

## Slot rule

Each bracket slot must have a stable id.

Examples:

- `R32-L-M1A`
- `R32-L-M1B`
- `R16-L-S1`
- `QF-L-S1`
- `SF-L-S1`
- `FINAL-A`
- `FINAL-B`
- `CHAMPION`

## State preservation

When generating a new HTML version, preserve all existing state unless a change is explicitly required.

## Screenshot rule

The HTML should be visually clear enough that a screenshot can help recover bracket state, but screenshots are secondary.

Canonical order:

1. exported JSON
2. embedded JSON
3. HTML DOM state
4. screenshot interpretation
