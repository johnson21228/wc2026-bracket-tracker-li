# Source Authority Rule

## Purpose

This rule governs how World Cup facts enter the Workbench.

## Accepted fact types

The Workbench may record:

- qualified teams
- group assignments
- match dates
- match scores
- match winners
- knockout advancement
- disciplinary or tie-break status if relevant
- official corrections

## Source priority

Use sources in this order:

1. FIFA official tournament sources
2. official federation or competition pages
3. official broadcaster match centers
4. reputable sports data or news sources
5. user-provided manual override

## Manual overrides

A manual override is allowed, but it must be explicitly marked.

Each override must record:

- who supplied it
- what fact changed
- why it was accepted
- whether it needs later verification

## No silent updates

Never silently change:

- a score
- a winner
- a player pick
- a scoring rule
- a bracket slot
- a release version

Every factual update requires a capture note.
