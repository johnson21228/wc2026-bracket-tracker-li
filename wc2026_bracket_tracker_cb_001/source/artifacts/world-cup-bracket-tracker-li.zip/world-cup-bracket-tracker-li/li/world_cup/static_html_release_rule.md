# Static HTML Release Rule

## Purpose

The tracker should remain usable as a single static HTML file.

The static file may be:

- opened locally from Downloads
- emailed or messaged
- served from GitHub Pages
- hosted on a simple web server
- pasted back into an II reasoner for updates

## Required visible metadata

Every HTML release should show:

- title
- release version
- generated date
- tournament state date
- scoring rule summary
- source note or source list

## Required embedded data

Every HTML release should include a machine-readable JSON state block.

Preferred pattern:

```html
<script id="workbench-state" type="application/json">
{ ... }
</script>
```

## Release naming

Use monotonically increasing releases.

Example:

```text
world_cup_bracket_tracker_v001.html
world_cup_bracket_tracker_v002.html
world_cup_bracket_tracker_v003.html
```

## Release immutability

Do not edit old releases in place. Create a new release.

## GitHub Pages path

When hosted on GitHub Pages, the current public version should be copied or built to:

```text
index.html
```
