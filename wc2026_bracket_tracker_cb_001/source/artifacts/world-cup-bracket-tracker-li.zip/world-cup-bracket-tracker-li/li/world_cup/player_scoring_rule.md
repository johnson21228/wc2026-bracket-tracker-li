# Player Scoring Rule

## Purpose

This rule governs bracket pool players, picks, and scoring.

## Player record

Each player should have:

```json
{
  "playerId": "stable-id",
  "displayName": "Name",
  "submittedAt": "ISO-8601 date",
  "picks": {
    "winnerByMatchId": {},
    "champion": null
  },
  "score": {
    "total": 0,
    "byRound": {}
  },
  "status": "draft|submitted|locked|corrected",
  "changeLog": []
}
```

## Scoring rules

Scoring must be declared before scoring begins.

Default suggested scoring:

- Round of 32 correct winner: 1 point
- Round of 16 correct winner: 2 points
- Quarterfinal correct winner: 4 points
- Semifinal correct winner: 8 points
- Final correct champion: 16 points

The Workbench may use a different scoring system only if recorded in `source/scoring_rules.md`.

## Lock rule

Once the tournament begins, player picks should be locked unless the pool owner explicitly allows corrections.

Corrections must be recorded as corrections, not overwritten history.

## Scoring update rule

Every scoring update must state:

- matches newly scored
- players affected
- point changes
- leaderboard changes
- unresolved matches
