# Update Capture Rule

## Purpose

Capture Back preserves the tournament history and prevents silent drift.

## Required capture note

Every update should produce a note containing:

```text
WB_SESSION:
World Cup Bracket Tracker Update

Changed:
- ...

Sources:
- ...

Data affected:
- teams:
- matches:
- bracket:
- players:
- scores:

Release:
- previous:
- new:

Unresolved:
- ...

Next:
- ...
```

## When capture is required

Capture is required after:

- adding or correcting teams
- changing group structure
- entering match results
- advancing teams
- scoring players
- changing scoring rules
- releasing new HTML
- moving from local HTML to GitHub Pages or server hosting

## Anti-drift rule

If the II reasoner is unsure whether the HTML, JSON, or Workbench files are current, it must ask for the latest exported JSON or latest HTML before making scoring or bracket changes.
